using UnityEngine;

namespace MLAgents
{
    public class Area : MonoBehaviour
    {
        public virtual void ResetArea()
        {
        }
    }
}
