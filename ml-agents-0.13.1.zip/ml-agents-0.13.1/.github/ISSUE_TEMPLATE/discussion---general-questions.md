---
name: Discussion / General Questions
about: Discussion about ML-Agents, RL algorithms, or game integrations
title: ''
labels: discussion
assignees: ''

---

Describe what you'd like to discuss.

**Note**: The ML-Agents team has limited resources for education and community discussion.  We'll participate as we are able, but encourage members of the community to support one another to discuss and support one another.
